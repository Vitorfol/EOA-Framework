# EOA Framework - Guia do Fluxo de Uso Idealizado (Developer Journey)

> *"Nossa, quem desenvolveu isso realmente se importou em fazer algo limpo, intuitivo e fácil de usar."*  
> — Esse é o nosso padrão de qualidade e a sensação que todo desenvolvedor deve ter ao importar a biblioteca.

Este documento detalha **como o desenvolvedor vai usar o framework no dia a dia**, cobrindo do caso mais simples e rápido até as customizações mais avançadas de sistemas industriais e legados.

---

## 🧭 Visão Geral dos Cenários de Uso

| Cenário | Descrição do Caso de Uso | Esforço do Dev |
| :--- | :--- | :--- |
| **Cenário 1** | **Plug & Play (3 Linhas)**: Explicar um alerta básico sem configurar nada. | ⚡ < 1 min |
| **Cenário 2** | **Conexão com LLM Flexível**: 3 formas diferentes de conectar a IA. | 🔌 1 min |
| **Cenário 3** | **"O Desenvolvedor é Rei"**: Remover agentes, trocar prompts por `.md`. | 🛠️ 3 min |
| **Cenário 4** | **Chat Multi-Turn e Banco SQLite**: Conversar com o agente e auditar o `.db`. | 💬 2 min |
| **Cenário 5** | **Manuais Técnicos Gigantes**: Busca estruturada padrão vs. Plugando RAG. | 📚 4 min |
| **Cenário 6** | **Integração num Sistema Real (FastAPI / Backend Legado)**: Degradação graciosa. | 🏭 5 min |
| **Cenário 7** | **Modo Autônomo com Tools (Query-Based)**: Passar apenas o ID do alerta e deixar agentes buscarem. | 🤖 3 min |
| **Cenário 8** | **Rampa Progressiva (Zero ML Inicial)**: Consultas de manuais e regras antes de ter modelo de ML pronto. | 🚀 < 1 min |

---

## ⚡ Cenário 1: Uso Plug & Play (Início Imediato em Poucas Linhas)

O desenvolvedor acabou de instalar via `pip install eoa` e só quer explicar uma anomalia detectada pelo modelo XGBoost dele.

```python
import eoa

# 1. Cria a camada padrão com o modelo desejado (o EOA gerencia tudo)
layer = eoa.ExplanationLayer.default_layer(provider="gemini", api_key="AIzaSy...", model="gemini-2.5-flash")

# 2. Pede a explicação passando os dados brutos da predição
response = layer.explain(
    prediction={
        "target_variable": "Condição do Resfriador",
        "predicted_value": "Eficiência Reduzida (20%)",
        "confidence_or_probability": 0.82
    },
    xai={
        "feature_attributions": {"PS1_pressao": 0.45, "EPS1_potencia_motor": 0.35, "TS2_temperatura": 0.20}
    },
    user_query="Explique por que esse alerta disparou e o que devo verificar."
)

# 3. Usa o resultado limpo e validado
print(response.narrative)
# -> "O alerta de risco de 82% decorre do aumento simultâneo na pressão axial (PS1) e potência..."

print(f"Nota da Auditoria Técnica: {response.validation_score}/10")
# -> "Nota da Auditoria Técnica: 9.6/10"
```

---

## 🔌 Cenário 2: Flexibilidade na Conexão com LLM (3 Modos)

O desenvolvedor não é obrigado a usar nossa abstração se não quiser. Ele tem controle total de como a IA é chamada:

```python
import eoa

# -------------------------------------------------------------
# Modo 2A: Chave e Modelo Direto (Para scripts rápidos)
# -------------------------------------------------------------
layer_facil = eoa.ExplanationLayer(
    provider="gemini", 
    api_key="MINHA_CHAVE", 
    model="gemini-2.5-flash"
)

# -------------------------------------------------------------
# Modo 2B: Cliente que ele JÁ tem instanciado no sistema dele
# (Ótimo para quem usa proxy corporativo, certificados TLS de usina ou LiteLLM)
# -------------------------------------------------------------
from google import genai
cliente_corporativo = genai.Client(api_key="...", http_options={"proxy": "http://proxy.fabrica:8080"})

layer_cliente = eoa.ExplanationLayer(llm=cliente_corporativo)

# -------------------------------------------------------------
# Modo 2C: Função Própria (Para modelos locais como Ollama, vLLM ou IA interna)
# -------------------------------------------------------------
def meu_llm_local(prompt: str) -> str:
    # Chama o Ollama, vLLM ou uma API interna da empresa
    return servidor_interno_ia.predict(prompt)

layer_custom = eoa.ExplanationLayer(llm=meu_llm_local)
```

---

## 🛠️ Cenário 3: "O Desenvolvedor é Rei" (Customização Total de Agentes)

O desenvolvedor não quer usar o agente de contexto (`CMA`) porque o sistema dele é muito simples, mas quer criar um agente especialista em turbinas hidráulicas usando um arquivo `.md` que a equipe de engenharia escreveu.

```python
import eoa

# Cria uma camada limpa
layer = eoa.ExplanationLayer(provider="gemini", api_key="...")

# 1. Carrega os agentes padrão (CMA, AA, EA, VA)
layer.create_default_agents()

# 2. Não precisa do CMA neste projeto? Desliga com uma linha:
layer.remove_agent("context_manager")

# 3. O prompt padrão do Explainer não tem o tom desejado?
# Sobrescreve cirurgicamente o prompt apontando para um arquivo .md ou string:
layer.override_agent_prompt("explainer", Path("meus_prompts/explainer_industrial.md"))

# 4. Quer adicionar um Especialista Próprio?
# Como o prompt PTCF já define a Persona, o construtor é super enxuto:
layer.register_agent(SpecializedAgent(
    name="turbina_francis",
    prompt=Path("meus_prompts/turbina_francis.md"),
))

# 5. Lista no terminal para inspecionar como a camada ficou configurada
layer.inspect()
# Exibe no terminal uma tabela limpa e formatada:
# [Agente]        [Status]   [Origem do Prompt]
# Orchestrator    Ativo      Built-in
# AA (Artifacts)  Ativo      Built-in
# EA (Explainer)  Ativo      meus_prompts/explainer_industrial.md
# VA (Validator)  Ativo      Built-in (Threshold: 7.0/10)
# Especialista..  Ativo      meus_prompts/turbina_francis.md
```

---

## 💬 Cenário 4: Chat Multi-Turn e Banco SQLite (O Dev é Dono do `.db`)

O operador quer tirar dúvidas contínuas sobre o alerta em um chat interativo. Todas as perguntas e respostas ficam guardadas num arquivo SQLite local.

```python
import eoa

# =========================================================================
# Forma A: Usando integrado com a ExplanationLayer (Automático)
# =========================================================================
layer = eoa.ExplanationLayer(
    provider="gemini",
    api_key="...",
    # O arquivo .db é criado e inicializado automaticamente (zero dependências)
    session_store=eoa.SQLiteSessionStore(db_path="meus_alertas.db"),
)

# Turno 1: Passa predição e pergunta inicial vinculados à sessão do incidente
res1 = layer.explain(
    prediction=pred_dados,
    xai=xai_dados,
    user_query="O que significa essa vibração no sensor PS1?",
    session_id="incidente_turbina_04",
)
print(res1.narrative)

# Turno 2: Pergunta subsequente (o agente lembra do contexto e das evidências anteriores!)
res2 = layer.explain(
    user_query="Isso tem risco iminente de cavitação se mantivermos a carga atual?",
    session_id="incidente_turbina_04",
)
print(res2.narrative)


# =========================================================================
# Forma B: Usando o SQLiteSessionStore Diretamente (Auditoria & RAG)
# =========================================================================
store = eoa.SQLiteSessionStore("meus_alertas.db")

# 1. Recuperar histórico tipado em Python
historico = store.get_history("incidente_turbina_04")
for msg in historico:
    print(f"[{msg.timestamp}] {msg.role.upper()}: {msg.content}")

# 2. Exportar como dicionários puros para alimentar pipelines externos ou RAG
dados = store.export_dict("incidente_turbina_04")
# Mensagens prontas para indexação ou logging corporativo:
mensagens_para_rag = [m["content"] for m in dados["messages"]]
logs_de_validacao = dados["validation_logs"]

# 3. Auditoria SQL direta no banco (DBeaver, VS Code, PowerBI):
# SELECT role, content, timestamp FROM messages WHERE session_id = 'incidente_turbina_04';
# SELECT score, passed, critique FROM validation_logs WHERE session_id = 'incidente_turbina_04';
```

---

## 📚 Cenário 5: Manuais Técnicos Gigantes (Estruturado vs. Plugando RAG)

Como lidar com manuais de equipamentos industriais de centenas de páginas?

```python
import eoa

layer = eoa.ExplanationLayer.default_layer(provider="gemini", api_key="...")

# -------------------------------------------------------------
# Opção A: Padrão do Paper (Estruturado - Leve, Rápido e Seguro)
# O dev passa apenas os capítulos ou esquemas mapeados do subsistema afetado:
# -------------------------------------------------------------
response = layer.explain(
    prediction=pred_dados,
    xai=xai_dados,
    context={
        "sistema": "Resfriamento Hidráulico",
        "manual_snippet": "Capítulo 4.2: Trocas térmicas anormais ocorrem quando EPS1 > 3.0kW...",
        "sensor_dictionary": {"PS1": "Pressão de entrada", "EPS1": "Potência consumida"}
    },
    user_query="Explique o alerta.",
)

# -------------------------------------------------------------
# Opção B: O Dev TEM um PDF gigante de 500 páginas e QUER usar RAG?
# Ele não fica travado! Ele pluga o próprio mecanismo de busca dele:
# -------------------------------------------------------------
def meu_buscador_vetorial(query: str) -> str:
    # Aqui o dev pode usar LangChain, LlamaIndex, ChromaDB, Elasticsearch, etc.
    trechos_relevantes = meu_indice_faiss.similarity_search(query, k=3)
    return "\n".join([t.page_content for t in trechos_relevantes])

# Pluga no ContextManagerAgent (CMA):
cma = layer.get_agent("context_manager")
cma.set_retriever(meu_buscador_vetorial)

# Pronto! Agora o CMA consulta o manual de 500 páginas sob demanda
```

---

## 🏭 Cenário 6: Sistema Real em Produção (FastAPI e Fail-Safe)

Exemplo de como plugar o EOA numa rota de API existente de monitoramento. Se o LLM cair ou a internet falhar, **o sistema principal de monitoramento não para**!

```python
from fastapi import FastAPI, HTTPException
import eoa

app = FastAPI(title="Planta Hidrelétrica - Monitoramento")
explanation_layer = eoa.ExplanationLayer.default_layer(provider="gemini", api_key="...")

@app.post("/api/v1/monitorar")
async def monitorar_sensor(leitura: dict):
    # 1. Pipeline preditivo principal (Nível 1 & 2)
    predicao = meu_modelo_ml.predict(leitura)
    xai_importancias = calcular_shap(meu_modelo_ml, leitura)

    # 2. Camada de Explicação (Nível 3) - Desacoplada e Segura
    explicacao = explanation_layer.explain(
        prediction=predicao,
        xai=xai_importancias,
        user_query="Resuma a saúde do equipamento",
    )

    # 3. Retorna a resposta completa
    return {
        "status_operacional": predicao["status"],
        "risco": predicao["probabilidade"],
        # Se a IA falhar ou o validador reprovar, o fallback_used será True
        # mas o operador ainda vê os dados essenciais!
        "explicacao_texto": explicacao.narrative,
        "validacao_aprovada": explicacao.validation_passed,
        "auditoria_score": explicacao.validation_score,
        "fallback_utilizado": explicacao.fallback_used,
    }
```

---

## 🤖 Cenário 7: Modo Autônomo com Tools (Query-Based Integration)

O desenvolvedor **não quer calcular ou passar o SHAP nem a predição na mão**. Ele prefere que os agentes recuperem esses dados autonomamente através de ferramentas/funções registradas (cumprindo a promessa do paper do SBES):

```python
import eoa

layer = eoa.ExplanationLayer.default_layer(provider="gemini", api_key="...")

# 1. Registra ferramentas de recuperação no ArtifactsAgent e ContextManagerAgent:
aa = layer.get_agent("artifacts")
aa.register_tool(minha_funcao_que_busca_shap_no_banco_ou_mlflow)

cma = layer.get_agent("context_manager")
cma.register_tool(minha_funcao_que_busca_sensores_no_scada)

# 2. Na hora de explicar, o dev passa identificadores agnósticos via query_params
# (ou usa o atalho conveniente incident_id="alerta_turbina_981"):
response = layer.explain(
    query_params={"prediction_id": "pred_402", "equipment_id": "turbina_981"},
    user_query="O que causou este alerta e qual a criticidade?",
)

# 3. Os agentes executam as tools que casam com os parâmetros fornecidos,
# montam os contratos internamente, sintetizam e validam a explicação de forma 100% autônoma!
print(response.narrative)
```

---

## 🚀 Cenário 8: Rampa Progressiva (Zero ML Inicial / Onboarding Imediato)

O desenvolvedor acabou de instalar o framework e ainda **não tem o modelo preditivo nem o SHAP calculados**, mas quer testar o pipeline e obter explicações baseadas em manuais e regras operacionais. O framework não o trava:

```python
import eoa

layer = eoa.ExplanationLayer.default_layer(provider="gemini", api_key="...")

# O dev passa apenas a dúvida e o contexto do subsistema (prediction e xai são opcionais):
response = layer.explain(
    user_query="Qual é o procedimento de segurança se a pressão PS1 passar de 4.0 bar?",
    context={
        "manual_regras": "Procedimento 12: Se PS1 > 4.0 bar, acione o bypass e isole a linha.",
        "sensores": {"PS1": "Pressão de entrada da linha de fluido"},
    },
)

# O CMA processa as regras, o Explainer redige a instrução e o Validador audita:
print(response.narrative)
# -> "Conforme o Procedimento 12, caso a pressão de entrada (PS1) exceda 4.0 bar,
#     o operador deve acionar imediatamente a válvula de bypass e isolar a linha..."
print(f"Auditoria: {response.validation_score}/10")
```
