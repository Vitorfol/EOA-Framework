# Condition monitoring of hydraulic systems — Documentation

## 1. Title
Condition monitoring of hydraulic systems

## 2. Source Information
- **Creator:** Nikolai Helwig, ZeMA gGmbH, Eschberger Weg 46, 66121 Saarbrücken
- **Donors (with approval from creator):** M. Bastuck (m.bastuck@lmt.uni-saarland.de), T. Schneider (t.schneider@zema.de)
- **Date:** April, 2018

## 3. Past Usage
1. **Nikolai Helwig, Eliseo Pignanelli, Andreas Schütze**, *‘Condition Monitoring of a Complex Hydraulic System Using Multivariate Statistics’*, in Proc. I2MTC-2015 - 2015 IEEE International Instrumentation and Measurement Technology Conference, paper PPS1-39, Pisa, Italy, May 11-14, 2015. doi: 10.1109/I2MTC.2015.7151267
   - detailed description of data and measurement setup
   - automated feature extraction via Pearson correlation and comparison of several classification algorithms
   - Cooler and Valve states are "easy" targets (perfect classification achieved), Pump and especially Accumulator states are more complex targets
2. **N. Helwig, A. Schütze**, *‘Detecting and compensating sensor faults in a hydraulic condition monitoring system’*, in Proc. SENSOR 2015 - 17th International Conference on Sensors and Measurement Technology, oral presentation D8.1, Nuremberg, Germany, May 19-21, 2015. doi: 10.5162/sensor2015/D8.1
   - sensor drift and offset can be compensated by the automatic feature extraction described in [1]
   - faults of up to 5 sensors can be compensated for
3. **Tizian Schneider, Nikolai Helwig, Andreas Schütze**, *‘Automatic feature extraction and selection for classification of cyclical time series data’*, tm - Technisches Messen (2017), 84(3), 198–206. doi: 10.1515/teme-2016-0072
   - one of several example datasets for automatic feature extraction
   - with ALA and RFESVM the error rate was reduced to 0.35 % (from 9.6 % in [1]) for the hydraulic accumulator state classification

## 4. Relevant Information
The data set was experimentally obtained with a hydraulic test rig. This test rig consists of a primary working and a secondary cooling-filtration circuit which are connected via the oil tank [1], [2]. The system cyclically repeats constant load cycles (duration 60 seconds) and measures process values such as pressures, volume flows and temperatures while the condition of four hydraulic components (cooler, valve, pump and accumulator) is quantitatively varied.

## 5. Number of Instances
`2205`

## 6. Number of Attributes
`43680` (`8x60` (1 Hz) + `2x600` (10 Hz) + `7x6000` (100 Hz))

## 7. Attribute Information
Attributes are sensor data (all numeric and continuous) from measurements taken at the same point in time, respectively, of a hydraulic test rig's working cycle.
The sensors were read with different sampling rates, leading to different numbers of attributes per sensor despite they were all exposed to the same working cycle.

1. **Pressure sensors (`PS1`–`PS6`):** 100 Hz, 6000 attributes per sensor (6 sensors)
2. **Motor power sensor (`EPS1`):** 100 Hz, 6000 attributes per sensor (1 sensor)
3. **Volume flow sensors (`FS1`–`FS2`):** 10 Hz, 600 attributes per sensor (2 sensors)
4. **Temperature sensors (`TS1`–`TS4`):** 1 Hz, 60 attributes per sensor (4 sensors)
5. **Vibration sensor (`VS1`):** 1 Hz, 60 attributes per sensor (1 sensor)
6. **Efficiency factor (`SE`):** 1 Hz, 60 attributes per sensor (1 sensor)
7. **Virtual cooling efficiency sensor (`CE`):** 1 Hz, 60 attributes per sensor (1 sensor)
8. **Virtual cooling power sensor (`CP`):** 1 Hz, 60 attributes per sensor (1 sensor)

## 8. Missing Attribute Values
None

## 9. Class Distribution (`profile.txt`)
There are 5 different class value vectors provided in `profile.txt`.
All but number 5 (stable flag) describe degradation processes over time and, thus, their values do not represent distinct categories, but continuous values.

1. **Cooler condition / %:**
   - `3`: close to total failure (732 instances)
   - `20`: reduced efficiency (732 instances)
   - `100`: full efficiency (741 instances)
2. **Valve condition / %:**
   - `100`: optimal switching behavior (1125 instances)
   - `90`: small lag (360 instances)
   - `80`: severe lag (360 instances)
   - `73`: close to total failure (360 instances)
3. **Internal pump leakage:**
   - `0`: no leakage (1221 instances)
   - `1`: weak leakage (492 instances)
   - `2`: severe leakage (492 instances)
4. **Hydraulic accumulator / bar:**
   - `130`: optimal pressure (599 instances)
   - `115`: slightly reduced pressure (399 instances)
   - `100`: severely reduced pressure (399 instances)
   - `90`: close to total failure (808 instances)
5. **Stable flag:**
   - `0`: conditions were stable (1449 instances)
   - `1`: static conditions might not have been reached yet (756 instances)
